package peoject1;

import java.io.IOException;

public class ATM_Machine extends Menu{
	public static void main(String[] args) throws IOException {
		new Menu().getLogin();
	}
}
